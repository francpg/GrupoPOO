package app;

import formularios.Formulario;
public class Ejecutar {

   
    public static void main(String[] args) {
    Formulario iniciar = new Formulario();
    iniciar.setLocationRelativeTo(null);
    iniciar.setDefaultCloseOperation(iniciar.EXIT_ON_CLOSE);
    iniciar.setVisible(true);           
    }    
}
